package com.wgh.actionForm;


public class MoreSelect{
	private String[] answerArr=new String[4];
	public String[] getAnswerArr(){
		return answerArr;
	}
	public void setAnswerArr(String[] answerArr){
		this.answerArr=answerArr;
	}
}
